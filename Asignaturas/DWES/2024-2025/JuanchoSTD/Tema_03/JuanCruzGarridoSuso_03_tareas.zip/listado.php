<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>Listado de Productos</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <h1>Listado de Productos</h1>
  <p><a href="crear.php" class="boton">Crear nuevo producto</a></p>
<?php
  require_once 'conexion.php';
  $consulta = "SELECT p.*, f.nombre as nombre_familia FROM productos p, familias f WHERE p.familia = f.cod";
  $sentencia = $conexion->prepare($consulta);
  try {
    $sentencia->execute();
  } catch (PDOException $ex) {
    die("Error: " . $ex->getMessage());
  }
  $numResultados = $sentencia->rowCount();
  if ($numResultados == 0) {
    echo "<h1>NO se han encontrado registros</h1>";
  } else {
?>
    
    <table border="1">
      <tr>
        <th>Detalle</th>
        <th>Código</th>
        <th>Nombre</th>
        <th colspan="2">Acciones</th>
      </tr>
<?php
    while ($fila = $sentencia->fetch(PDO::FETCH_OBJ)) {
?>
      <tr>
        <td><a href="detalle.php?id=<?php echo $fila->id; ?>"> <input type="button" value="Detalle" class="boton"></a></td>
        <td><?php echo $fila->id; ?></td>
        <td><?php echo $fila->nombre; ?></td>
        <td><a href="update.php?id=<?php echo $fila->id; ?>"> <input type="button" value="Editar" class="boton"></a></td>
        <td>
          <form action="borrar.php" method="POST" class="form_solo_boton" onsubmit="return confirm('De verdad?');">
            <input type="hidden" name="id" value="<?php echo $fila->id; ?>">
            <input type="submit" value="Borrar" class="boton">
          </form>
        </td>
      </tr>
<?php
      }
      $sentencia = null;
      $conexion = null;
?>
    </table>
<?php
  } 
?>

</body>

</html>