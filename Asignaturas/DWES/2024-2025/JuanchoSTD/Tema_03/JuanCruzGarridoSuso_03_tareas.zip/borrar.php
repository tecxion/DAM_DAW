<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>Borrar Producto</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <h1>Borrar Producto</h1>
  <?php
  // Comprobamos que llegue el id del producto a borrar
  if (!isset($_POST["id"])) {
    header('Location: listado.php');
    exit(); // Es importante poner exit después de header, según leo, para evitar que se ejecute más código
  }
  require_once 'conexion.php';
  //COnsulta DELETE
  $consulta = "DELETE FROM productos WHERE id = " . $_POST["id"];
  $sentencia = $conexion->prepare($consulta);
  try {
    $sentencia->execute();
  } catch (PDOException $ex) {
    die("Error: " . $ex->getMessage());
  }
  // Eliminamos la conexión y la consulta
  $sentencia = null;
  $conexion = null;
  ?>
  <p>Producto de código: <?php echo $_POST["id"]; ?> borrado correctamente
  
  <a href='listado.php'> <input type='button' value='Volver al listado' class='boton'></a>
  </p>
</body>

</html>