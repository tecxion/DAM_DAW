<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>Crear nuevo producto</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <h1>Crear nuevo producto</h1>
  <?php
  if (isset($_POST["nombre"])) {
    require_once 'conexion.php';
    try {
      //Consulta INSERT
      $consulta = "INSERT INTO productos(nombre, nombre_corto, descripcion, pvp, familia) VALUES ('" .
        $_POST["nombre"] . "', '" .
        $_POST["nombre_corto"] . "', '" .
        $_POST["descripcion"] . "', " .
        $_POST["pvp"] . ", '" .
        $_POST["familia"] . "')";

      $sentencia = $conexion->prepare($consulta);
      $sentencia->execute();

      $sentencia = null;
      $conexion = null;
      echo "<p>Producto creado correctamente</p>";
      echo "<p><a href='listado.php'> <input type='button' value='Volver al listado' class='boton'></a>";
    } catch (PDOException $ex) {
      die("Error: " . $ex->getMessage());
    }
  } else {
  ?>
    <form method="POST">
      <p>Nombre: <input type="text" name="nombre" required></p>
      <p>Nombre corto: <input type="text" name="nombre_corto" required></p>
      <p>Descripción: <textarea name="descripcion"></textarea></p>
      <p>Precio (PVP): <input type="number" step="0.01" name="pvp" min="0.01" required></p>
      <p>Familia:
        <select name="familia" required>
          <?php
          require_once 'conexion.php';
          $consulta = "SELECT cod, nombre FROM familias ORDER BY nombre";
          $sentencia = $conexion->prepare($consulta);
          $sentencia->execute();
          while ($fila = $sentencia->fetch(PDO::FETCH_ASSOC)) {
            echo "<option value='{$fila['cod']}'>{$fila['nombre']}</option>";
          }
          $sentencia = null;
          $conexion = null;
          ?>
        </select>
      </p>
      <p><input type="submit" value="Crear"></p>
    </form>
  <?php
  }
  ?>
</body>

</html>