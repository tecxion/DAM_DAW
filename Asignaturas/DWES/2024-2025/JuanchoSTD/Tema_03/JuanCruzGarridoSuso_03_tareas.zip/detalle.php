<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Detalles del Producto</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <h1>Detalles del Producto</h1>
    <?php
    if (!isset($_GET["id"])) {
        header('Location: listado.php');
        exit(); // Es importante poner exit después del header
    } else {
        require_once 'conexion.php';
        $consulta = "SELECT p.*, f.nombre as nombre_familia FROM productos p, familias f WHERE id = '" . $_GET["id"] . "' AND p.familia = f.cod";
        // echo $consulta;
        $sentencia = $conexion->prepare($consulta);
        try {
            $sentencia->execute();

            if ($sentencia->rowCount() == 0) {
                header('Location: listado.php');
                exit();
            }

            $producto = $sentencia->fetch(PDO::FETCH_OBJ);
    ?>
            <table border="1">
                <tr>
                    <th>Código:</th>
                    <td><?php echo $producto->id; ?></td>
                </tr>
                <tr>
                    <th>Nombre:</th>
                    <td><?php echo $producto->nombre; ?></td>
                </tr>
                <tr>
                    <th>Nombre Corto:</th>
                    <td><?php echo $producto->nombre_corto; ?></td>
                </tr>
                <tr>
                    <th>Descripción:</th>
                    <td><?php echo nl2br($producto->descripcion); ?></td>
                </tr>
                <tr>
                    <th>PVP:</th>
                    <td><?php echo number_format($producto->pvp, 2, ',', '.'); ?>€</td>
                </tr>
                <tr>
                    <th>Familia:</th>
                    <td><?php echo $producto->nombre_familia; ?></td>
                </tr>
            </table>

            <p>
                <a href="update.php?id=<?php echo $producto->id; ?>"> <input type="button" value="Editar" class="boton"></a>
                <a href='listado.php'> <input type='button' value='Volver al listado' class='boton'></a>
            </p>
    <?php
        } catch (PDOException $ex) {
            die("Error: " . $ex->getMessage());
        }
    } 
    $sentencia = null;
    $conexion = null;
    ?>
</body>

</html>