<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Actualizar Producto</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <h1>Actualizar Producto</h1>
    <?php
    require_once 'conexion.php';

    if (isset($_GET["id"])) { //Aquí recibimos por GET, lo que singnofoca que es la entrada, la visualización del contenido actual

        $consulta = "SELECT p.*, f.nombre as nombre_familia
               FROM productos p, familias f
               WHERE id ='" . $_GET["id"] . "' and p.familia = f.cod";
        $sentencia = $conexion->prepare($consulta);
        try {
            $sentencia->execute();

            //echo $sentencia -> rowCount();
            if ($sentencia -> rowCount() == 0) {
                header('Location: listado.php');
                exit();
            }

            $producto = $sentencia->fetch(PDO::FETCH_OBJ);
    ?>
            <form method="POST" action="?">
                <input type="hidden" name="id" value="<?php echo $producto->id; ?>">
                <p>Nombre: <input type="text" name="nombre" value="<?php echo $producto->nombre; ?>" required></p>
                <p>Nombre corto: <input type="text" name="nombre_corto" value="<?php echo $producto->nombre_corto; ?>" required></p>
                <p>Descripción: <textarea name="descripcion"><?php echo $producto->descripcion; ?></textarea></p>
                <p>PVP: <input type="number" step="0.01" name="pvp" min="0.01" value="<?php echo $producto->pvp; ?>" required></p>
                <p>Familia:
                    <select name="familia" required>
                        <?php
                        //rellenamos el select, hacemos el fetch en notación de objeto
                        $consulta = "SELECT cod, nombre FROM familias";
                        $sentencia = $conexion->prepare($consulta);
                        $sentencia->execute();
                        while ($familia = $sentencia->fetch(PDO::FETCH_OBJ)) {
                            $selected = "";
                            if (($familia->cod == $producto->familia)) {
                                $selected = "selected";
                            }
                            echo "<option value='{$familia->cod}' $selected>{$familia->nombre}</option>";
                        }
                        ?>
                    </select>
                </p>
                <p>
                    <input type="submit" value="Actualizar" class='boton'>
                    <a href='listado.php'> <input type='button' value='Volver al listado' class='boton'></a>
                </p>
            </form>
        <?php
        } catch (PDOException $ex) {
            die("Error: " . $ex->getMessage());
        }
    } else if (isset($_POST["id"])){ // Aquí recibimos por POST (todos los campos, aunque solo compruebo el id), y eso implica que es la actualización en bbdd
        try {
            $consulta = "UPDATE productos SET nombre ='" . $_POST["nombre"] . "', " .
                "nombre_corto = '" . $_POST["nombre_corto"] . "', " .
                "descripcion = '" . $_POST["descripcion"] . "', " .
                "pvp = '" . $_POST["pvp"] . "', " .
                "familia = '" . $_POST["familia"] . "' " .
                "WHERE id =" . $_POST["id"] . ";";
            //echo $consulta;
            $sentencia = $conexion->prepare($consulta);
            $sentencia->execute();
        ?>
            <p>Producto actualizado correctamente</p>
            <p><a href='listado.php'> <input type='button' value='Volver al listado' class='boton'></a></p>
    <?php
        } catch (PDOException $ex) {
            die("Error: " . $ex->getMessage());
        }
    }else{ // Esto implica que no tenemos id ni por post ni por get
        // NOs deshacemos de las variables asociadas a la conexión y la consulta a la bbdd
        $sentencia = null;
        $conexion = null;
        header('Location: listado.php');
        exit();
        
    }
    // NOs deshacemos de las variables asociadas a la conexión y la consulta a la bbdd
    $sentencia = null;
    $conexion = null;
    ?>
</body>

</html>