package biblioteca;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FicheroLibros {

	private static final String DELIMITADOR = ";";
	
	/**
	 * Considera éxito que el archivo esté, aunque no contenga libros legibles
	 * @param f
	 * @param b
	 * @return
	 */
	public static Resultado leerFichero(String f, Biblioteca b) {

		if (f == null) {
			return Resultado.fallo("No se ha proporcionado un path válido para el fichero");
		}
		if (b == null) {
			return Resultado.fallo("Debe existir una biblioteca");
		}

		try (BufferedReader br = new BufferedReader(new FileReader(f))) {

			String linea;
			int procesados = 0;
			int ignorados = 0; // ~ lineasIgnoradasMensaje.size() 
			List<String> lineasIgnoradasMensaje = new ArrayList<String>();
			String formato = "Ignorada línea: %d, texto: \n%s\n%s";
			while ((linea = br.readLine()) != null) {
				if (linea.isBlank()) {
					ignorados++;
					lineasIgnoradasMensaje.add(String.format(formato, (procesados + ignorados), linea, " - línea vacía"));
					continue;
				}
				String[] partes = linea.split(DELIMITADOR);
				if (partes.length != 4) {
					ignorados++;
					lineasIgnoradasMensaje.add(String.format(formato, (procesados + ignorados), linea, " - línea mal formada"));
					continue;
				}

				String titulo = partes[0].trim();
				String autor = partes[1].trim();
				String isbn = partes[2].trim();
				String dispStr = partes[3].trim().toLowerCase();
				if (!dispStr.equals("true") && !dispStr.equals("false")) {
					ignorados++;
					lineasIgnoradasMensaje.add(String.format(formato, (procesados + ignorados), linea, " - booleano defectuoso o faltante"));
					continue;
				}
				boolean disponible = Boolean.parseBoolean(dispStr);

				Resultado resultAnyadir = b.anyadirLibro(new Libro(isbn, titulo, autor, disponible));
				if (!resultAnyadir.isExito()) {
					ignorados++;
					lineasIgnoradasMensaje.add(String.format(formato, (procesados + ignorados), linea, " - ") + resultAnyadir.getMensaje());
					continue;
				}

				procesados++;
			}

			return Resultado.exito("Carga completada. Libros leídos: " + procesados + ". Líneas ignoradas: " + ignorados
					+ ((ignorados > 0) ? ":\n" + String.join("\n", lineasIgnoradasMensaje) : ""));

		} catch (FileNotFoundException e) {
			return Resultado.fallo("El fichero de datos no existe (" + f + "). Se creará al guardar.");
		} catch (IOException e) {
			return Resultado.fallo("Error crítico leyendo el fichero: " + e.getMessage());
		}
	}

	public static Resultado escribirFichero(String f, Biblioteca b) {

		if (f == null) {
			return Resultado.fallo("Debes proporcionar un path válido para el fichero");
		}
		if (b == null) {
			return Resultado.fallo("Debe existir una biblioteca");
		}

		try (BufferedWriter bw = new BufferedWriter(new FileWriter(f))) {
			for (Libro l : b.getLibros().values()) {
				String registroLibro = String.join(DELIMITADOR, l.getTitulo(), l.getAutor(), l.getIsbn()) + ";"
						+ l.isDisponible();
				bw.write(registroLibro);
				bw.newLine();
			}
			return Resultado
					.exito("Fichero guardado correctamente, con " + b.getLibros().values().size() + " registros");
		} catch (IOException e) {
			return Resultado.fallo("Error al escribir fichero: \n" + e.getMessage());
		}
	}
}
