package biblioteca;

public class Libro {
	
	/**
	 * Son finales por que un libro no debería poder cambiar de isbn, titulo o autor
	 */
	private final String isbn;
	private final String titulo;
	private final String autor;
	
	private boolean disponible;
	
	//No se persiste para no perjudicar el ejercicio
	private int numPrestamos = 0;
	
	/**
	 * Un libro como tal es aceptable en cualquier estado, 
	 * la biblioteca debe juzgar si cumple los requisitos o no
	 * 
	 * @param isbn
	 * @param titulo
	 * @param autor
	 * @param disponible
	 */
	public Libro(String isbn, String titulo, String autor, boolean disponible) {
		this.isbn = isbn;
		this.titulo = titulo;
		this.autor = autor;
		this.disponible = disponible;
	}
	public String getIsbn() {
		return isbn;
	}
	public String getTitulo() {
		return titulo;
	}
	public String getAutor() {
		return autor;
	}
	public boolean isDisponible() {
		return disponible;
	}
	
//	No hay setter, un libro se presta o se devuelve, pero no se establece con el setter
//	public void setDisponible(boolean disponible) {
//		this.disponible = disponible;
//	}
	
	public int getNumPrestamos() {
		return numPrestamos;
	}
	
	/*
	 * En mi opinión, la lógica de préstamos es cosa de biblioteca
	 * ya que es la biblioteca la que presta.
	 */
	public Resultado prestar() {
		if (disponible) {
			disponible = false;
			numPrestamos++;
			return Resultado.exito("Libro prestado con éxito", this);
		}
		return Resultado.fallo("No se puede prestar un libro que no está disponible", this);
	}
	public Resultado devolver() {
		if (!disponible) {
			disponible = true;
			return Resultado.exito("Libro devuelto con éxito", this);
		}
		return Resultado.fallo("No se puede devolver un libro disponible", this);
	}
	@Override
	public String toString() {
		return String.join(", ", autor, titulo, isbn, getDisponibilidad(), String.valueOf(numPrestamos) + " préstamos");
	}
	public String getDisponibilidad() {
		return disponible?"Disponible":"No disponible";
	}
	

	
}
