package biblioteca;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Biblioteca {

	/**
	 * Opto por un LinkedHashMap, recojo así la unicidad del código isbn, la
	 * búsqueda eficiente y el orden de entrada de los libros, garantizando que el
	 * contenido tenga un orden natural
	 */
	private Map<String, Libro> libros = new LinkedHashMap<String, Libro>();
	
	/**
	 * Único modo de añadir un libro en la biblioteca gracias a que
	 * no exponemos un map modificable, aquí se valida si un libro es aceptable o no
	 * 
	 * @param libro
	 * @return
	 */
	public Resultado anyadirLibro(Libro libro) {

		if (libro == null) {
			return Resultado.fallo("ERROR: libro no existe");
		}

		List<String> erroresLibro = new ArrayList<>();
		if (noInformado(libro.getIsbn())) {
			erroresLibro.add(" - No consta isbn");
		}
		if (noInformado(libro.getTitulo())) {
			erroresLibro.add(" - No consta un título");
		}
		if (noInformado(libro.getAutor())) {
			erroresLibro.add(" - No consta un autor");
		}
		if (!erroresLibro.isEmpty()) {
			return Resultado.fallo("ERROR: No se puede añadir libro:\n" + String.join("\n", erroresLibro));
		}

		// Errores en biblioteca
		if (libros.containsKey(libro.getIsbn())) {
			return Resultado.fallo("ERROR: No se puede añadir libro, ya estaba en biblioteca, isbn:" + libro.getIsbn());
		}

		// Todo en orden
		libros.put(libro.getIsbn(), libro);
		return Resultado.exito("Añadido exitósamente", libro);
	}

	private boolean noInformado(String valor) {
		return valor == null || valor.isBlank();
	}

	public Resultado buscarISBN(String isbn) {
		if (isbn == null || isbn.isBlank()) {
			return Resultado.fallo("No se encuentra el libro, ISBN no proporcionado");
		}	
		
		Libro libro = libros.get(isbn);
		if (libro == null) {
			return Resultado.fallo("No se encuentra el libro de isbn:\n" + isbn);
		}

		return Resultado.exito("Libro seleccionado exitósamente", libro);
	}

	public Resultado prestarLibro(String isbn) {
		Resultado result = buscarISBN(isbn);

		if (!result.isExito()) {
			return result;
		}

		return result.getLibro().prestar();

	}

	public Resultado devolverLibro(String isbn) {
		Resultado result = buscarISBN(isbn);

		if (!result.isExito()) {
			return result;
		}

		return result.getLibro().devolver();
	}
	/**
	 * Incluyo la eliminación de libro en la funcionalidad
	 * @param isbn
	 * @return
	 */
	public Resultado eliminarLibro(String isbn) {
		Resultado result = buscarISBN(isbn);

		if (!result.isExito()) {
			return result;
		}
		if (!result.getLibro().isDisponible()) {
			return Resultado.fallo("Libro prestado, no se puede eliminar", result.getLibro());
		}
		libros.remove(result.getLibro().getIsbn());
		return Resultado.exito("Libro eliminado exitósamente", result.getLibro());
	}

	/**
	 * Esto es lógica de presentación, se incluye aquí xk se pide explícitamente en
	 * el ejercicio.
	 */
	public void mostrarListadoDeLibros() {
		if (libros.isEmpty()) {
			System.out.println(" - No hay libros en la biblioteca");
		}
		libros.values().forEach(System.out::println);
	}

	/*
	 * EL mapa que devolvemos no se puede modificar,
	 * la modificación de esta collección es solo cosa de Biblioteca.
	 */
	public Map<String, Libro> getLibros() {
		return Collections.unmodifiableMap(libros);
	}

	

}
