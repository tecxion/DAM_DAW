package biblioteca;

public class Resultado {
	
	private final boolean exito;
	private final String mensaje;
	private final Libro libro;
	
	/**
	 * Se implementa para facilitar a las interfaces alejarse de la lógica del modelo.
	 * 
	 * @param exito
	 * @param mensaje
	 * @param libro
	 */
	
	private Resultado(boolean exito, String mensaje, Libro libro) {
		this.exito = exito;
		this.mensaje = mensaje;
		this.libro = libro;
	}
	
	public static Resultado exito(String mensaje, Libro libro) {
		return new Resultado(true, mensaje, libro);
	}
	public static Resultado exito(String mensaje) {
		return exito(mensaje, null);
	}
	public static Resultado fallo(String mensaje, Libro libro) {
		return new Resultado(false, mensaje, libro);
	}
	public static Resultado fallo(String mensaje) {
		return fallo(mensaje, null);
	}

	public boolean isExito() {
		return exito;
	}

	public String getMensaje() {
		return mensaje;
	}

	public Libro getLibro() {
		return libro;
	}

	@Override
	public String toString() {
		return mensaje + (libro != null ? ":\n " + libro.toString():"");
	}
	
	
	
}
