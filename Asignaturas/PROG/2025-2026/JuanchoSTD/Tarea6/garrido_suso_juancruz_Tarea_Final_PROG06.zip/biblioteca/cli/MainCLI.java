package biblioteca.cli;

import java.util.Scanner;

import biblioteca.Biblioteca;
import biblioteca.FicheroLibros;
import biblioteca.Libro;

public class MainCLI {

	private Biblioteca biblioteca = new Biblioteca();
	private Scanner scanner = new Scanner(System.in);
	private static final String PATH_FICHERO = "./datos_biblioteca.csv";

	public static void main(String[] args) {

		System.out.println("\n**********   BIENVENIDO AL SISTEMA DE BIBLIOTECA   **********\n");
		MainCLI mainCLI = new MainCLI();

		while (mainCLI.menu())
			;

		System.out.println("Adiós!");
	}

	public MainCLI() {
		System.out.println(FicheroLibros.leerFichero(PATH_FICHERO, biblioteca));
	}

	private boolean menu() {

		System.out.println("\nMenú principal, elija una opción:\n");
		System.out.println("1 - Añadir libro (se añade como disponible)");
		System.out.println("2 - Mostrar libros");
		System.out.println("3 - Prestar libro");
		System.out.println("4 - Devolver libro");
		System.out.println("5 - Buscar libro por ISBN");
		System.out.println("6 - Guardar datos en fichero");
		System.out.println("7 - Eliminar libro");
		System.out.println("8 - Salir");

		switch (leerEntero()) {
		case 1:
			return anyadirLibro();
		case 2:
			return mostrarLibros();
		case 3:
			return prestarLibro();
		case 4:
			return devolverLibro();
		case 5:
			return buscarLibroPorISBN();
		case 6:
			return guardarDatosEnFichero();
		case 7:
			return eliminarLibro();
		case 8:
			return false;
		default:
			System.out.println("Elige una opción válida!");
			return true;
		}

	}

	private boolean eliminarLibro() {
		System.out.println("Proporciona el ISBN del libro que deseas eliminar:");
		String isbn = leerStringNoVacio();
		System.out.println(biblioteca.eliminarLibro(isbn));
		return true;
	}

	private boolean guardarDatosEnFichero() {

		System.out.println(FicheroLibros.escribirFichero(PATH_FICHERO, biblioteca).getMensaje());

		return true;
	}

	private boolean buscarLibroPorISBN() {
		System.out.println("Proporciona el ISBN:");
		String ISBN = leerStringNoVacio();
		System.out.println(biblioteca.buscarISBN(ISBN));
		return true;
	}

	private boolean devolverLibro() {
		System.out.println("Proporciona el ISBN del libro que deseas devolver:");
		String isbn = leerStringNoVacio();
		System.out.println(biblioteca.devolverLibro(isbn));
		return true;
	}

	private boolean prestarLibro() {

		System.out.println("Proporciona el ISBN del libro que deseas prestar:");
		String isbn = leerStringNoVacio();
		System.out.println(biblioteca.prestarLibro(isbn));
		return true;
	}

	private boolean mostrarLibros() {
		System.out.println("Listado de libros:");
		biblioteca.mostrarListadoDeLibros(); //Esto debería hacerse aquí
		return true;
	}

	private boolean anyadirLibro() {
		System.out.println("Introduce el autor:");
		String autor = leerStringNoVacio();

		System.out.println("Introduce el título:");
		String titulo = leerStringNoVacio();

		System.out.println("Introduce el ISBN:");
		String isbn = leerStringNoVacio();

		// NO se especifica, asumo disponibilidad
		System.out.println(biblioteca.anyadirLibro(new Libro(isbn, titulo, autor, true)));

		return true;
	}

	private String leerStringNoVacio() {
		String s = scanner.nextLine().trim();
		while (s.isBlank()) {
			System.out.println("introduce un texto no vacío");
			s = scanner.nextLine();
		}
		return s;
	}

	private int leerEntero() {
		while (true) {
			try {
				return Integer.parseInt(scanner.nextLine());
			} catch (NumberFormatException e) {
				System.out.println("Solo se aceptan números enteros!");
			}
		}
	}
}
