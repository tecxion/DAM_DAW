package biblioteca.gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;

import biblioteca.Biblioteca;
import biblioteca.FicheroLibros;
import biblioteca.Libro;
import biblioteca.Resultado;

public class MainGUI {

	private Biblioteca biblioteca;
	private JFrame frame;
	private JPanel panelPrincipal;
	private JTable librosTable;
	private JTextField isbnField;
	private JTextField tituloField;
	private JTextField autorField;
	private JButton anyadirButton;
	private JButton buscarButton;
	private JButton prestarButton;
	private JButton devolverButton;
	private DefaultTableModel librosTableModel;
	private JButton guardarButton;
	private JButton mostrarLibrosButton;
	private JButton limpiarButton;
	private JButton eliminarButton;

	private static final String PATH_FICHERO = "./datos_biblioteca.csv";

	/**
	 * Opto por composición en vez de herencia sobre JFrame,
	 * no veo necesidad en exponer un JFrame
	 */
	public MainGUI() {
		this.biblioteca = new Biblioteca();

		construirGUI();

		Resultado resultLecturaArchivo = FicheroLibros.leerFichero(PATH_FICHERO, biblioteca);
		
		if (!resultLecturaArchivo.isExito()) {
			mostrarDialogoError(resultLecturaArchivo.toString());
		} else {
			actualizaDatosLibros();
			mostrarDialogo(resultLecturaArchivo);
		}
	}

	private void construirGUI() {
		frame = new JFrame("Biblioteca");

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(1150, 600);
		frame.setMinimumSize(frame.getSize());
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);

		panelPrincipal = new JPanel();
		panelPrincipal.setLayout(new BorderLayout(10, 10));
		panelPrincipal.setBorder(new EmptyBorder(15, 15, 15, 15));

		// Tabla de libros
		librosTableModel = new DefaultTableModel(new String[] { "ISBN", "Título", "Autor", "Disponibilidad", "Número Préstamos" }, 0) {
			@Override
			public boolean isCellEditable(int row, int column) {
				return false; // tabla solo lectura
			}
		};

		librosTable = new JTable(librosTableModel);
		JScrollPane scrollLibrosPanel = new JScrollPane(librosTable);
		panelPrincipal.add(scrollLibrosPanel, BorderLayout.CENTER);

		// Datos de entrada
		JPanel entradaDatosPanel = new JPanel();
		entradaDatosPanel.setLayout(new GridLayout(3, 2, 8, 8));

		isbnField = new JTextField();
		tituloField = new JTextField();
		autorField = new JTextField();

		entradaDatosPanel.add(new JLabel("ISBN:"));
		entradaDatosPanel.add(isbnField);
		entradaDatosPanel.add(new JLabel("Título:"));
		entradaDatosPanel.add(tituloField);
		entradaDatosPanel.add(new JLabel("Autor:"));
		entradaDatosPanel.add(autorField);

		panelPrincipal.add(entradaDatosPanel, BorderLayout.NORTH);

		// Botones
		JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
		anyadirButton = new JButton("Añadir Libro");
		buscarButton = new JButton("Buscar ISBN");
		prestarButton = new JButton("Prestar Libro");
		devolverButton = new JButton("Devolver Libro");
		eliminarButton = new JButton("Eliminar Libro");
		mostrarLibrosButton = new JButton("Mostrar Libros");
		guardarButton = new JButton("Guardar librería");
		limpiarButton = new JButton("Limpiar Formulario");

		buttonPanel.add(anyadirButton);
		buttonPanel.add(mostrarLibrosButton);
		buttonPanel.add(prestarButton);
		buttonPanel.add(devolverButton);
		buttonPanel.add(eliminarButton);		
		buttonPanel.add(buscarButton);
		buttonPanel.add(limpiarButton);
		buttonPanel.add(guardarButton);

		panelPrincipal.add(buttonPanel, BorderLayout.SOUTH);

		frame.add(panelPrincipal);

		// Eventos
		anyadirButton.addActionListener(e -> accionAnyadir());
		buscarButton.addActionListener(e -> accionBuscar());
		prestarButton.addActionListener(e -> accionPrestar());
		devolverButton.addActionListener(e -> accionDevolver());
		mostrarLibrosButton.addActionListener(e -> accionActualizar());
		guardarButton.addActionListener(e -> accionGuardar());
		limpiarButton.addActionListener(e -> limpiarFormulario());
		eliminarButton.addActionListener(e -> accionEliminarLibro());

		// Click en libro, facilita mucho el uso
		librosTable.getSelectionModel().addListSelectionListener(e -> clickEnLibro(e));
	}

	private void mostrarDialogo(Resultado resultado) {
		if (resultado.isExito()) {
			mostrarDialogoInfo(resultado.toString());
		} else {
			mostrarDialogoAviso(resultado.toString());
		}
	}

	private void mostrarDialogoError(String mensaje) {
		JOptionPane.showMessageDialog(frame, mensaje, "Error:", JOptionPane.ERROR_MESSAGE);
	}

	private void mostrarDialogoInfo(String mensaje) {
		JOptionPane.showMessageDialog(frame, mensaje, "OK!", JOptionPane.INFORMATION_MESSAGE);
	}

	private void mostrarDialogoAviso(String mensaje) {
		JOptionPane.showMessageDialog(frame, mensaje, "Aviso:", JOptionPane.WARNING_MESSAGE);
	}

	private void limpiarFormulario() {
		tituloField.setText("");
		autorField.setText("");
		isbnField.setText("");
		tituloField.requestFocus();
	}

	private void actualizaDatosLibros() {
		librosTableModel.setRowCount(0); // Limpiar
		for (Libro libro : biblioteca.getLibros().values()) {
			librosTableModel.addRow(
					new Object[] { libro.getIsbn(), libro.getTitulo(), libro.getAutor(), libro.getDisponibilidad(), libro.getNumPrestamos()});
		}
	}

	private void accionAnyadir() {
		String isbn = isbnField.getText().trim();
		String titulo = tituloField.getText().trim();
		String autor = autorField.getText().trim();
		// NO se especifica, asumo disponibilidad
		Libro nuevoLibro = new Libro(isbn, titulo, autor, true);

		Resultado resultado = biblioteca.anyadirLibro(nuevoLibro);

		if (resultado.isExito()) {
			actualizaDatosLibros();
			limpiarFormulario();
		}
		mostrarDialogo(resultado);
	}

	private void accionBuscar() {
		String isbn = isbnField.getText().trim();
		
		Resultado result = biblioteca.buscarISBN(isbn);
		if (result.isExito()) {
			isbnField.setText(result.getLibro().getIsbn());
			tituloField.setText(result.getLibro().getTitulo());
			autorField.setText(result.getLibro().getAutor());
		}
		mostrarDialogo(result);
	}

	private void accionPrestar() {
		String isbn = isbnField.getText().trim();
		Resultado resultado = biblioteca.prestarLibro(isbn);
		if (resultado.isExito()) {
			actualizaDatosLibros();
		}
		mostrarDialogo(resultado);
	}

	private void accionDevolver() {
		String isbn = isbnField.getText().trim();
		Resultado resultado = biblioteca.devolverLibro(isbn);
		if (resultado.isExito()) {
			actualizaDatosLibros();
		}
		mostrarDialogo(resultado);
	}

	private void accionGuardar() {
		Resultado resultado = FicheroLibros.escribirFichero(PATH_FICHERO, biblioteca);
		if (!resultado.isExito()) {
			mostrarDialogoError(resultado.toString());
		} else {
			mostrarDialogo(resultado);
		}
	}

	private void accionEliminarLibro() {
		String isbn = isbnField.getText().trim();
		Resultado resultado = biblioteca.eliminarLibro(isbn);
		if (resultado.isExito()) {
			actualizaDatosLibros();
		}
		mostrarDialogo(resultado);
	}
	
	private void accionActualizar() {
		actualizaDatosLibros();
	}

	private void clickEnLibro(ListSelectionEvent e) {
		if (!e.getValueIsAdjusting()) {
			int filaSeleccionada = librosTable.getSelectedRow();

			if (filaSeleccionada != -1) {
				String isbn = librosTableModel.getValueAt(filaSeleccionada, 0).toString();
				String titulo = librosTableModel.getValueAt(filaSeleccionada, 1).toString();
				String autor = librosTableModel.getValueAt(filaSeleccionada, 2).toString();

				isbnField.setText(isbn);
				tituloField.setText(titulo);
				autorField.setText(autor);
			}
		}
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(MainGUI::new);
	}
}
