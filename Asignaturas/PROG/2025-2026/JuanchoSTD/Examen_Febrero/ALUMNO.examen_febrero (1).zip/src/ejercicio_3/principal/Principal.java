package ejercicio_3.principal;

import ejercicio_3.modelo.Producto;

public class Principal {

	public static void main(String[] args) {
		Producto producto1 = new Producto("Prueba 1", "Categoría 1", 12.3);
		Producto producto2 = new Producto("Prueba 2", "Categoría 2");
		
		System.out.println("Productos recién instanciados:");
		System.out.println(producto1.toString());
		System.out.println(producto2.toString());
		
		producto2.activarProducto();
		producto1.cambiarPrecio(99.99);

		System.out.println("\nProductos tras las operqaciones solicitadas:");
		System.out.println(producto1.toString());
		System.out.println(producto2.toString());
		
		System.out.println("Total de productos creados: " + Producto.getTotalProductos());
		
		
		
	}
}
