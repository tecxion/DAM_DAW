package ejercicio_3.modelo;

public class Producto {

	private String nombre;
	private String categoria;
	private double precio;
	private boolean disponible;

	private static int totalProductos = 0;

	public Producto(String nombre, String categoria, double precio) {

		this.nombre = nombre;
		this.categoria = categoria;
		this.precio = precio;
		this.disponible = true;
		totalProductos++;
	}

	public Producto(String nombre, String categoria) {

		this.nombre = nombre;
		this.categoria = categoria;
		this.precio = 0;
		this.disponible = false;
		totalProductos++;
	}
	
	public void activarProducto() {
		this.disponible = true;
	}
	public void desactivarProducto() {
		this.disponible = false;
	}
	public void cambiarPrecio(double nuevoPrecio) {
		this.precio = nuevoPrecio;
	}
	public String obtenerDisponiblilidad() {
		return this.disponible?"DISPONIBLE":"NO DISPONIBLE";
	}

	public static int getTotalProductos() {
		return totalProductos;
	}
	
	@Override
	public String toString() {
		return "Producto [nombre=" + nombre + ", categoria=" + categoria + ", precio=" + precio + ", disponible="
				+ obtenerDisponiblilidad() + "]";
	}
	
	
	

}
