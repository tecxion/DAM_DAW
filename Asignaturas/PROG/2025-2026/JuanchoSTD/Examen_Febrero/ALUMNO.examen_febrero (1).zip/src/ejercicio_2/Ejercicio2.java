package ejercicio_2;

import java.util.Scanner;

public class Ejercicio2 {
	
	private Scanner scanner = new Scanner(System.in);
	private static int n = 0;
	
	public static void main(String[] args) {
		
		System.out.println("Ejercicio 2");
		
		Ejercicio2 ejercicio = new Ejercicio2();
				
		do {
			System.out.println("Introduce un número mayor que cero");
			n = ejercicio.leerEntero();
		} while (!(n>0));
		
		boolean continuar = true;
		
		do {
			continuar = ejercicio.menu();
		}while(continuar);
		
		System.out.println("Adiós!");
	}


	private boolean menu() {
		
		System.out.println("Elige una opción, sobre el número elegido: " + n);
		System.out.println("1 - Sumar los números pares");
		System.out.println("2 - Sumar los múltiplos de un número k");
		System.out.println("3 - Mostrar los números no primos");
		System.out.println("4 - Salir");
		
		int opcion = leerEntero();
		
		switch (opcion) {
		case 1:
			sumarLosPares();
			break;
		case 2:
			sumarMultiplos();
			break;
		case 3:
			mostrarNoPrimos();
			break;
		case 4:
			return false;	
		default:
			System.out.println("Introduce una opción válida");
		}
			
		return true;
	}

	private void mostrarNoPrimos() {
		System.out.println("Los números que no son primos entre 1 y " + n + " son:");
		
		for (int i = 0; i <= n; i++) {
			if (!esPrimo(i)) {
				System.out.println(i);
			}
		}
	}

	private boolean esPrimo(int numero) {
		for (int i = 2; i < numero; i++) {
			if (numero%i == 0) {
				return false;
			}
		}
		return true;
	}
	
	/**
	 * Entiendo que se pide la suma de la serie k*1 + k*2 + .... k*n = k*(1+...+n) 
	 */
	private void sumarMultiplos() {
		int k = 0;
		do {
			System.out.println("Introduce un número mayor que cero");
			k = leerEntero();
		} while (!(k>0));
		
		int suma = 0;
		
		for (int i = 0; i <= n; i++) {
			suma += k*i;
		}
		
		System.out.println("El resultado es: " + suma);
	}


	private void sumarLosPares() {
		
		int suma = 0;
				
		for (int i = 0; i <= n; i = i+2) {//vamos de dos en dos empezando en cero, todo i es par
			suma += i;
		}
		
		System.out.println("El resultado es: " + suma);	
	}


	private int leerEntero() {
		
		int leido = 0;
		boolean correcto = false;	
		do {
			try {
				leido = Integer.parseInt(scanner.nextLine());
				correcto = true;
			} catch (NumberFormatException e) {
				System.out.println("Introduce un número entero");
			} 
		} while (!correcto);
		
		return leido;
		
	}
}
