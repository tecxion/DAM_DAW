package ejercicio_1;

public class VehiculoElectrico {

	private String modelo;
	private double bateria;
	private double consumoKm;
	private double kilometrosRecorridos;

	public VehiculoElectrico(String modelo, double consumoKm) {

		this.modelo = modelo;
		this.consumoKm = consumoKm;
		this.bateria = 100;
		this.kilometrosRecorridos = 0;
	}

	/**
	 * Valido que el recorrido sea posible dada la batería que nos queda, 
	 * no se pide, pero pienso que es mejor, sería más sencilo no hacerlo
	 * @param kilometros
	 */
	public void recorrer(double kilometros) {
		if (kilometros < 0) {
			System.out.println("La distancia recorrida debe ser >0 a cero");
			return;
		}

		double consumo = kilometros * this.consumoKm;

		if (bateria == Math.max(bateria, consumo)) {
			this.bateria -= consumo;
			this.kilometrosRecorridos += kilometros;
		} else {
			System.out.println("Nivel de batería insuficiente para ese trayecto");
		}
	}

	public void recargar(double porcentaje) {
		if (porcentaje < 0) {
			System.out.println("La recarga debe ser mayor o igual a cero");
			return;
		}
		this.bateria = Math.min(this.bateria + porcentaje, 100);
	}

	public String estadoBateria() {

		return (this.bateria >= 60) ? "BUENA" : ((this.bateria >= 20) ? "MEDIA" : "CRÍTICA");

	}

	public void mostrarInformacion() {

		System.out.println("VehiculoElectrico [modelo=" + modelo + ", bateria=" + bateria + ", kilometrosRecorridos="
				+ kilometrosRecorridos + ", estado bateria: " + estadoBateria() + "]");
	}

}
