package ejercicio_1;

import java.util.Scanner;

public class Principal {

	private static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {

		VehiculoElectrico vehiculoElectrico = new VehiculoElectrico("Prueba", 2);

		System.out.println("Bienvenido al sistema de gestión de vículos eléctricos");

		double kms = 0;
		double recarga = 0;

		do {
			System.out.println("Introduce los kilómetros a recorrer, debe ser número positivo");
			kms = leerDouble();
		} while (!(kms > 0));
		
		vehiculoElectrico.recorrer(kms);
		
		do {
			System.out.println("Introduce la recarga a realizar, debe ser número positivo");
			recarga = leerDouble();
		} while (!(recarga >= 0));
		
		vehiculoElectrico.recargar(recarga);
		
		System.out.println("El resultado de estas actuaciones es:");
		vehiculoElectrico.mostrarInformacion();

	}

	private static double leerDouble() {

		double leido = 0;
		boolean correcto = false;
		do {
			try {
				leido = Double.parseDouble(scanner.nextLine());
				correcto = true;
			} catch (NumberFormatException e) {
				System.out.println("Introduce un número con decimales");
			}
		} while (!correcto);

		return leido;

	}
}
