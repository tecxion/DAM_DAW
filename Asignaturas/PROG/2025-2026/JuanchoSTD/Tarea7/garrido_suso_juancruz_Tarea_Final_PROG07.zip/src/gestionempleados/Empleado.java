package gestionempleados;

import java.util.ArrayList;
import java.util.List;

public abstract class Empleado implements Imprimible {

	protected String nombre;
	protected int edad;
	protected double salarioBase;

	protected Empleado(String nombre, int edad, double salarioBase) {

		this.nombre = nombre;
		this.edad = edad;
		this.salarioBase = salarioBase;
	}

	public List<String> validarEmpleado() {
		List<String> errores = new ArrayList<String>();
		errores.add(validaNombre(nombre));
		errores.add(validaEdad(edad));
		errores.add(validaSalarioBase(salarioBase));
		while (errores.remove(null))
			;
		return errores;
	}

	public static String validaNombre(String nombre) {
		if (nombre.isBlank()) {
			return "El empleado requiere un nombre";
		}
		return null;
	}

	public static String validaEdad(int edad) {
		if (edad < 16 || edad > 75) {
			return "El empleado debe estar en edad de trabajar";
		}
		return null;
	}

	public static String validaSalarioBase(double salarioBase) {
		if (salarioBase <= 0) {
			return "El empleado debe tener un salario";
		}
		return null;
	}

	public abstract double calcularSalario();

	public abstract String tipoEmpeado();

	public String mostrarInformacion() {
		return String.format("El %s %s disfruta de un salario completo de %.2f €", tipoEmpeado(), this.nombre,
				this.calcularSalario());
	}

	@Override
	public void imprimirDetalles() {
		System.out.println(this.mostrarInformacion());

	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public double getSalarioBase() {
		return salarioBase;
	}

	public void setSalarioBase(double salarioBase) {
		this.salarioBase = salarioBase;
	}

}
