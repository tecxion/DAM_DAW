package gestionempleados;

public interface Imprimible {

	public void imprimirDetalles();
}
