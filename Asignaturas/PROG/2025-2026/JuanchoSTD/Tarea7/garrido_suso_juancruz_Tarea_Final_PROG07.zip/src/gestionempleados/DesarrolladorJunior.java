package gestionempleados;

import java.util.List;

public class DesarrolladorJunior extends Empleado {

	private int horasExtra;

	public DesarrolladorJunior(String nombre, int edad, double salarioBase, int horasExtra) {
		super(nombre, edad, salarioBase);
		this.horasExtra = horasExtra;
	}
	@Override
	public List<String> validarEmpleado() {
		List<String> errores = super.validarEmpleado();
		errores.add(validaHorasExtra(horasExtra));
		while(errores.remove(null));
		return errores;
	}
	public static String validaHorasExtra(int horasExtra) {
		if (horasExtra < 0) {
			return "No se puede haber hecho menos de 0 horas extra";
		}
		return null;
	}

	@Override
	public double calcularSalario() {
		return this.salarioBase + (horasExtra*18);
	}
	@Override
	public String tipoEmpeado() {
		return "Desarrollador Júnior";
	}

	public int getHorasExtras() {
		return horasExtra;
	}

	public void setHorasExtras(int horasExtra) {
		this.horasExtra = horasExtra;
	}

	
}
