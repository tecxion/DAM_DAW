package gestionempleados;

public class GeneralManager extends Manager {

	public GeneralManager(String nombre, int edad, double salarioBase, double bono) {
		super(nombre, edad, salarioBase, bono);		
	}

	@Override
	public String tipoEmpeado() {
		return "Mánager General";
	}
	
}
