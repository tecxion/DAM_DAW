package gestionempleados;

import java.util.Scanner;

public class Principal {

	private Scanner scanner = new Scanner(System.in);
	private Empresa empresa = new Empresa();

	public static void main(String[] args) {
		System.out.println("Bienvenido al programa de gestión de empleados.");

		Principal p = new Principal();
		
		while (p.menu())
			;

		System.out.println("Adiós muy buenas!");
	}

	private boolean menu() {
		System.out.println("\nMenú de gestión, elija una opción:\n");

		System.out.println("1 - Registrar nuevo empleado");
		System.out.println("2 - Mostrar detalles de empleados");
		System.out.println("3 - Buscar empleado por nombre");
		System.out.println("4 - Salir");

		int opcion = leeEntero();

		switch (opcion) {
		case 1: {
			registrarNuevoEmpleado();
			return true;
		}
		case 2: {
			mostrarDetallesEpleados();
			return true;
		}
		case 3: {
			buscarEmpleadoPorNombre();
			return true;
		}
		case 4: {
			return false;
		}
		default:
			System.out.println("introduce una opción válida");
			return true;
		}
	}

	private void buscarEmpleadoPorNombre() {

		System.out.println("Escribe el nombre del empleado a buscar:");
		String nombreIntroducido = scanner.nextLine();
		Empleado empleado = empresa.buscarEmpleado(nombreIntroducido);
		if (empleado != null) {
			System.out.println("Empleado encontrado:");
			empleado.imprimirDetalles();
		} else {
			System.out.println("No se ha encontrado un empleado de nombre: " + nombreIntroducido);
		}

	}

	private void mostrarDetallesEpleados() {
		empresa.imprimirDetallesEmpleados();
	}

	private void registrarNuevoEmpleado() {
		String error = "";
		int tipoEmpleado = 0;
		do {
			System.out.println("Introduce el tipo de empleado (1-5):");
			System.out.println("1 - Socio");
			System.out.println("2 - Mánager General");
			System.out.println("3 - Mánager");
			System.out.println("4 - Desarrollador Sénior");
			System.out.println("5 - Desarrollador Júnior");
			tipoEmpleado = leeEntero();
		} while (tipoEmpleado < 1 || tipoEmpleado > 5);

		String nombre;
		do {
			System.out.println("Escribe el nombre:");
			nombre = scanner.nextLine();
			error = Empleado.validaNombre(nombre);
			if (error != null) {
				System.out.println(error);
			}
		} while (error != null);

		int edad;
		do {
			System.out.println("Escribe el edad:");
			edad = leeEntero();
			error = Empleado.validaEdad(edad);
			if (error != null) {
				System.out.println(error);
			}
		} while (error != null);

		double salariobase;
		do {
			System.out.println("Escribe el salario base:");
			salariobase = leerDouble();
			error = Empleado.validaSalarioBase(salariobase);
			if (error != null) {
				System.out.println(error);
			}
		} while (error != null);

		switch (tipoEmpleado) {
		case 1:
			int stockOptions;
			do {
				System.out.println("Indica las Stock options de este socio:");
				stockOptions = leeEntero();
				error = Socio.validarStockOptions(stockOptions);
				if (error != null) {
					System.out.println(error);
				}
			} while (error != null);

			empresa.agregarEmpleado(new Socio(nombre, edad, salariobase, stockOptions));
			break;
		case 2:
			double bono;
			do {
				System.out.println("Indica el bono de este Mánager General (mayor o igual a 0):");
				bono = leerDouble();
				error = GeneralManager.validaBono(bono);
				if (error != null) {
					System.out.println(error);
				}
			} while (error != null);
			empresa.agregarEmpleado(new GeneralManager(nombre, edad, salariobase, bono));
			break;

		case 3:
			do {
				System.out.println("Indica el bono de este Mánager (mayor o igual a 0):");
				bono = leerDouble();
				error = Manager.validaBono(bono);
				if (error != null) {
					System.out.println(error);
				}
			} while (error != null);
			empresa.agregarEmpleado(new Manager(nombre, edad, salariobase, bono));
			break;

		case 4:
			int horasTrabajadas;
			do {
				System.out.println("Indica las horas trabajadas de este desarrollador sénior:");
				horasTrabajadas = leeEntero();
				error = DesarrolladorSenior.validaHorastrabajadas(horasTrabajadas);
				if (error != null) {
					System.out.println(error);
				}
			} while (error != null);
			empresa.agregarEmpleado(new DesarrolladorSenior(nombre, edad, salariobase, horasTrabajadas));
			break;

		case 5:
			int horasExtra;
			do {
				System.out.println("indica las horas extra:");
				horasExtra = leeEntero();
				error = DesarrolladorJunior.validaHorasExtra(horasExtra);
				if (error != null) {
					System.out.println(error);
				}
			} while (error != null);
			empresa.agregarEmpleado(new DesarrolladorJunior(nombre, edad, salariobase, horasExtra));
			break;
		}
		System.out.println("Nuevo empleado agregado correctamente.");

	}

	private double leerDouble() {
		try {
			return Double.valueOf(scanner.nextLine());
		} catch (NumberFormatException e) {
			System.out.println("Introduce un número, por favor");
			return leerDouble();
		}
	}

	private int leeEntero() {
		try {
			return Integer.valueOf(scanner.nextLine());
		} catch (NumberFormatException e) {
			System.out.println("Introduce un número entero, por favor");
			return leeEntero();
		}
	}
}
