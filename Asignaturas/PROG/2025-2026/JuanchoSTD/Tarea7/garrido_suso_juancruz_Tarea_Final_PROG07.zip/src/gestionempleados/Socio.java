package gestionempleados;

import java.util.List;

public class Socio extends Empleado {

	private int stockOptions;

	protected Socio(String nombre, int edad, double salarioBase, int stockOptions) {
		super(nombre, edad, salarioBase);
		this.stockOptions = stockOptions;
	}

	@Override
	public List<String> validarEmpleado() {
		List<String> errores = super.validarEmpleado();
		errores.add(validarStockOptions(stockOptions));
		while (errores.remove(null))
			;
		return errores;
	}

	public static String validarStockOptions(int stockOptions) {
		if (stockOptions < 0) {
			return "No se pueden tener stock options negativas";
		}
		return null;
	}

	public double calcularSalario() {
		return this.salarioBase + stockOptions * 122;
	}

	@Override
	public String tipoEmpeado() {
		return "Socio";
	}

	public int getStockOptions() {
		return stockOptions;
	}

	public void setStockOptions(int stockOptions) {
		this.stockOptions = stockOptions;
	}

}
