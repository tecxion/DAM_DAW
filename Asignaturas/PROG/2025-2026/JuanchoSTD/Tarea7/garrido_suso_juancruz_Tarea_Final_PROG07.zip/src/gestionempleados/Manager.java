package gestionempleados;

import java.util.List;

public class Manager extends Empleado {

	private double bono;

	public Manager(String nombre, int edad, double salarioBase, double bono) {
		super(nombre, edad, salarioBase);
		this.bono = bono;
	}

	@Override
	public List<String> validarEmpleado() {
		List<String> errores = super.validarEmpleado();
		errores.add(validaBono(bono));
		while(errores.remove(null));
		return errores;
	}
	public static String validaBono(double bono) {
		if (bono < 0) {
			return "No se pueden tener un bono negativo";
		}
		return null;
	}
	
	@Override
	public String tipoEmpeado() {
		return "Mánager";
	}
	
	@Override
	public double calcularSalario() {
		return this.salarioBase + bono;
	}

}
