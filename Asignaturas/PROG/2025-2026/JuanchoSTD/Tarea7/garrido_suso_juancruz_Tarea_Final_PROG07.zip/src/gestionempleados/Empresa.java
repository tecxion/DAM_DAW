package gestionempleados;

import java.util.ArrayList;
import java.util.List;

public class Empresa {

	private List<Empleado> empleados = new ArrayList<Empleado>();

	public Empresa() {
		super();
	}

	public Empresa(List<Empleado> empleados) {
		super();
		this.empleados = empleados;
	}

	public boolean agregarEmpleado(Empleado e) {
		if (e.validarEmpleado().isEmpty()) {
			return this.empleados.add(e);
		}
		return false;
		
	}

	public void imprimirDetallesEmpleados() {
		if (empleados.isEmpty()) {
			System.out.println("No hay empleados en la empresa.");
			return;
		}
		System.out.println("Detalle de empleados:");
		empleados.forEach(Empleado::imprimirDetalles);
	}

	public Empleado buscarEmpleado(String porNombre) {
		//Solo el primero si hemos de cumplir con lo que se pide
		return empleados.stream().filter(e -> e.getNombre().equalsIgnoreCase(porNombre)).findFirst().orElse(null);
	}
}
