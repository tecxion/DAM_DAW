package gestionempleados;

import java.util.List;

public class DesarrolladorSenior extends Empleado {

	private int horasTrabajadas;
	
	
	public DesarrolladorSenior(String nombre, int edad, double salarioBase, int horasTrabajadas) {
		super(nombre, edad, salarioBase);
		this.horasTrabajadas = horasTrabajadas;
	}

	@Override
	public List<String> validarEmpleado() {
		List<String> errores = super.validarEmpleado();
		errores.add(validaHorastrabajadas(horasTrabajadas));
		while(errores.remove(null));
		return errores;
	}
	public static String validaHorastrabajadas(int horasTrabajadas) {
		if (horasTrabajadas < 0) {
			return "No se puede haber trabajado menos de 0 horas";
		}
		return null;
	}
	
	@Override
	public double calcularSalario() {
		return this.salarioBase + (horasTrabajadas*35);
	}

	@Override
	public String tipoEmpeado() {
		return "Desarrrolador Sénior";
	}

	public int getHorasTrabajadas() {
		return horasTrabajadas;
	}


	public void setHorasTrabajadas(int horasTrabajadas) {
		this.horasTrabajadas = horasTrabajadas;
	}

	
}
