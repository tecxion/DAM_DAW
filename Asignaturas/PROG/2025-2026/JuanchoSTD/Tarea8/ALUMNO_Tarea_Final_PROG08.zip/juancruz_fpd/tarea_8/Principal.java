package juancruz_fpd.tarea_8;

import java.util.List;
import java.util.Scanner;

public class Principal {

	private PeliculaDAO peliculaDAO = new PeliculaDAO();
	private Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {

		System.out.println("\n**********   BIENVENIDO AL SISTEMA DE PELÍCULAS   **********\n");

		// DatosPrueba.cargar();

		Principal principal = new Principal();
		while (principal.menu());

		System.out.println("\nHasta la vista!");
	}

	private boolean menu() {

		System.out.println("\nMenú principal, elija una opción:\n");
		System.out.println("1 - Insertar una película");
		System.out.println("2 - Actualizar duración de una película");
		System.out.println("3 - Eliminar una película");
		System.out.println("4 - Listar todas las películas");
		System.out.println("5 - Listar películas por género");
		System.out.println("6 - Salir");

		switch (leerEntero()) {
		case 1:  return insertarPelicula();
		case 2:  return actualizarDuracion();
		case 3:  return eliminarPelicula();
		case 4:  return listarTodas();
		case 5:  return listarPorGenero();
		case 6:  return false;
		default:
			System.out.println("Elige una opción válida!");
			return true;
		}
	}

	private boolean insertarPelicula() {

		System.out.println("Introduce el título:");
		String titulo = leerStringNoVacio();

		System.out.println("Introduce el director:");
		String director = leerStringNoVacio();

		System.out.println("Introduce el género:");
		String genero = leerStringNoVacio();

		System.out.println("Introduce el año de estreno:");
		int anio = leerEntero();

		System.out.println("Introduce la duración en minutos:");
		int duracion = leerEntero();

		Pelicula pelicula = new Pelicula(titulo, director, genero, anio, duracion);

		List<String> errores = pelicula.validarPelicula();
		if (!errores.isEmpty()) {
			System.out.println("No se pudo insertar la película por los siguientes errores:");
			errores.forEach(e -> System.out.println("  - " + e));
			return true;
		}

		System.out.println(peliculaDAO.insertar(pelicula));
		return true;
	}

	private boolean actualizarDuracion() {

		System.out.println("Introduce el título de la película:");
		String titulo = leerStringNoVacio();

		System.out.println("Introduce la nueva duración en minutos:");
		int duracion = leerEntero();

		String errorDuracion = Pelicula.validaDuracionMinutos(duracion);
		if (errorDuracion != null) {
			System.out.println("Duración no válida: " + errorDuracion);
			return true;
		}

		System.out.println(peliculaDAO.actualizarDuracion(titulo, duracion));
		return true;
	}

	private boolean eliminarPelicula() {
		System.out.println("Introduce el título de la película que deseas eliminar:");
		String titulo = leerStringNoVacio();
		System.out.println(peliculaDAO.eliminar(titulo));
		return true;
	}

	private boolean listarTodas() {
		List<Pelicula> peliculas = peliculaDAO.listarTodas();
		if (peliculas.isEmpty()) {
			System.out.println("No hay películas registradas.");
		} else {
			System.out.println("\nListado de películas:");
			peliculas.forEach(p -> System.out.println("  " + p));
		}
		return true;
	}

	private boolean listarPorGenero() {
		System.out.println("Introduce el género:");
		String genero = leerStringNoVacio();
		List<Pelicula> peliculas = peliculaDAO.listarPorGenero(genero);
		if (peliculas.isEmpty()) {
			System.out.println("No se encontraron películas del género: " + genero);
		} else {
			System.out.println("\nPelículas del género " + genero + ":");
			peliculas.forEach(p -> System.out.println("  " + p));
		}
		return true;
	}

	private String leerStringNoVacio() {
		String s = scanner.nextLine().trim();
		while (s.isBlank()) {
			System.out.println("Introduce un texto no vacío:");
			s = scanner.nextLine().trim();
		}
		return s;
	}

	private int leerEntero() {
		while (true) {
			try {
				return Integer.parseInt(scanner.nextLine().trim());
			} catch (NumberFormatException e) {
				System.out.println("Solo se aceptan números enteros!");
			}
		}
	}
}
