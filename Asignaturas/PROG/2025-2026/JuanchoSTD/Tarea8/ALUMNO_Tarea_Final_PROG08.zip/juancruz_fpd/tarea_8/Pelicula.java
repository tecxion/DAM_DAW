package juancruz_fpd.tarea_8;

import java.util.ArrayList;
import java.util.List;

public class Pelicula {

	protected int peliculaId;
	protected String titulo;
	protected String director;
	protected String genero;
	protected int anioEstreno;
	protected int duracionMinutos;

	public Pelicula(int peliculaId, String titulo, String director, String genero, int anioEstreno,
			int duracionMinutos) {
		this.peliculaId = peliculaId;
		this.titulo = titulo;
		this.director = director;
		this.genero = genero;
		this.anioEstreno = anioEstreno;
		this.duracionMinutos = duracionMinutos;
	}

	public Pelicula(String titulo, String director, String genero, int anioEstreno, int duracionMinutos) {
		this.titulo = titulo;
		this.director = director;
		this.genero = genero;
		this.anioEstreno = anioEstreno;
		this.duracionMinutos = duracionMinutos;
	}

	public List<String> validarPelicula() {
		List<String> errores = new ArrayList<>();
		errores.add(validaTitulo(titulo));
		errores.add(validaDirector(director));
		errores.add(validaGenero(genero));
		errores.add(validaAnioEstreno(anioEstreno));
		errores.add(validaDuracionMinutos(duracionMinutos));
		while (errores.remove(null))
			;
		return errores;
	}

	public static String validaTitulo(String titulo) {
		if (titulo == null || titulo.isBlank())
			return "El título no puede estar vacío.";
		if (titulo.length() > 100)
			return "El título no puede superar los 100 caracteres.";
		return null;
	}

	public static String validaDirector(String director) {
		if (director == null || director.isBlank())
			return "El director no puede estar vacío.";
		if (director.length() > 100)
			return "El director no puede superar los 100 caracteres.";
		return null;
	}

	public static String validaGenero(String genero) {
		if (genero == null || genero.isBlank())
			return "El género no puede estar vacío.";
		if (genero.length() > 50)
			return "El género no puede superar los 50 caracteres.";
		return null;
	}

	public static String validaAnioEstreno(int anioEstreno) {
		if (anioEstreno < 1888)
			return "El año de estreno no puede ser anterior a 1888.";
		if (anioEstreno > java.time.Year.now().getValue())
			return "El año de estreno no puede ser futuro.";
		return null;
	}

	public static String validaDuracionMinutos(int duracionMinutos) {
		if (duracionMinutos <= 0)
			return "La duración debe ser mayor que 0.";
		if (duracionMinutos > 600)
			return "La duración no puede superar los 600 minutos.";
		return null;
	}

	@Override
	public String toString() {
		return "Pelicula [peliculaId=" + peliculaId + ", titulo=" + titulo + ", director=" + director + ", genero="
				+ genero + ", anioEstreno=" + anioEstreno + ", duracionMinutos=" + duracionMinutos + "]";
	}

	public int getPeliculaId() {
		return peliculaId;
	}

	public String getTitulo() {
		return titulo;
	}

	public String getDirector() {
		return director;
	}

	public String getGenero() {
		return genero;
	}

	public int getAnioEstreno() {
		return anioEstreno;
	}

	public int getDuracionMinutos() {
		return duracionMinutos;
	}

	public void setPeliculaId(int peliculaId) {
		this.peliculaId = peliculaId;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	public void setAnioEstreno(int anioEstreno) {
		this.anioEstreno = anioEstreno;
	}

	public void setDuracionMinutos(int duracionMinutos) {
		this.duracionMinutos = duracionMinutos;
	}

}