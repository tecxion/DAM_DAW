package juancruz_fpd.tarea_8;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/*/*
 * No se valida nada, pero podría hacerse fácilmente
 */
public class PeliculaDAO {
	
	public String insertar(Pelicula pelicula) {
		String sql = "INSERT INTO catalogo (titulo, director, genero, anio_estreno, duracion_minutos) "
				+ "VALUES (?, ?, ?, ?, ?)";
		try (Connection conn = ConnectionDB.openConnection(); PreparedStatement ps = conn.prepareStatement(sql)) { // Interesante sintaxis
			ps.setString(1, pelicula.getTitulo());
			ps.setString(2, pelicula.getDirector());
			ps.setString(3, pelicula.getGenero());
			ps.setInt(4, pelicula.getAnioEstreno());
			ps.setInt(5, pelicula.getDuracionMinutos());
			ps.executeUpdate();
			return "Película insertada correctamente.";
		} catch (SQLException e) {
			return "Error al insertar la película: " + e.getMessage();
		}
	}

	public String actualizarDuracion(String titulo, int nuevaDuracion) {
		String sql = "UPDATE catalogo SET duracion_minutos = ? WHERE titulo = ?";
		try (Connection conn = ConnectionDB.openConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setInt(1, nuevaDuracion);
			ps.setString(2, titulo);
			int filas = ps.executeUpdate();
			if (filas == 0)
				return "No se encontró ninguna película con el título: " + titulo;
			return "Duración actualizada correctamente.";
		} catch (SQLException e) {
			return "Error al actualizar la duración: " + e.getMessage();
		}
	}

	public String eliminar(String titulo) {
		String sql = "DELETE FROM catalogo WHERE titulo = ?";
		try (Connection conn = ConnectionDB.openConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setString(1, titulo);
			int filas = ps.executeUpdate();
			if (filas == 0)
				return "No se encontró ninguna película con el título: " + titulo;
			return "Película eliminada correctamente.";
		} catch (SQLException e) {
			return "Error al eliminar la película: " + e.getMessage();
		}
	}

	public List<Pelicula> listarTodas() {
		List<Pelicula> lista = new ArrayList<>();
		String sql = "SELECT * FROM catalogo ORDER BY titulo";
		try (Connection conn = ConnectionDB.openConnection();
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet rs = ps.executeQuery()) {
			while (rs.next())
				lista.add(mapear(rs));
		} catch (SQLException e) {
			System.out.println("Error al listar las películas: " + e.getMessage());
		}
		return lista;
	}

	public List<Pelicula> listarPorGenero(String genero) {
		List<Pelicula> lista = new ArrayList<>();
		String sql = "SELECT * FROM catalogo WHERE genero LIKE ? COLLATE utf8mb4_general_ci ORDER BY titulo";
		try (Connection conn = ConnectionDB.openConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setString(1, "%" + genero.trim() + "%");
			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next())
					lista.add(mapear(rs));
			}
		} catch (SQLException e) {
			System.out.println("Error al listar por género: " + e.getMessage());
		}
		return lista;
	}

	private Pelicula mapear(ResultSet rs) throws SQLException {
		return new Pelicula(rs.getInt("pelicula_id"), rs.getString("titulo"), rs.getString("director"),
				rs.getString("genero"), rs.getInt("anio_estreno"), rs.getInt("duracion_minutos"));
	}
}
