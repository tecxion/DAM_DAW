package juancruz_fpd.tarea_8;

public class DatosPrueba {

	public static void cargar() {

		PeliculaDAO dao = new PeliculaDAO();

		Pelicula[] peliculas = { new Pelicula("El Imperio Contraataca", "Irvin Kershner", "Ciencia ficción", 1980, 124),
				new Pelicula("En Busca del Arca Perdida", "Steven Spielberg", "Aventura", 1981, 115),
				new Pelicula("Conan el Bárbaro", "John Milius", "Fantasía", 1982, 129),
				new Pelicula("El Retorno del Jedi", "Richard Marquand", "Ciencia ficción", 1983, 134),
				new Pelicula("La Historia Sin Fin", "Wolfgang Petersen", "Fantasía", 1984, 102),
				new Pelicula("Los Goonies", "Richard Donner", "Aventura", 1985, 114),
				new Pelicula("Dentro del Laberinto", "Jim Henson", "Fantasía", 1986, 101),
				new Pelicula("Princess Bride", "Rob Reiner", "Fantasía", 1987, 98),
				new Pelicula("Willow", "Ron Howard", "Fantasía", 1988, 126),
				new Pelicula("Indiana Jones y la Última Cruzada", "Steven Spielberg", "Aventura", 1989, 127),
				new Pelicula("Krull", "Peter Yates", "Fantasía", 1983, 117),
				new Pelicula("Excalibur", "John Boorman", "Fantasía", 1981, 140),
				new Pelicula("El Señor de las Bestias", "Don Coscarelli", "Fantasía", 1982, 118),
				new Pelicula("Ladyhawke", "Richard Donner", "Fantasía", 1985, 121), };

		System.out.println("Cargando datos de prueba...\n");
		for (Pelicula p : peliculas)
			System.out.println(dao.insertar(p) + " -> " + p.getTitulo());

		System.out.println("\nCarga completada: " + peliculas.length + " películas insertadas.");
	}
}