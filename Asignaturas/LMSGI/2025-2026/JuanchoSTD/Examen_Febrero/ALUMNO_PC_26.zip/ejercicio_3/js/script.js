window.onload = function () {
  var p = document.createElement("p");
  p.innerText = "Cálculo del área";
  p.style.color = "red";
  p.style.textAlign = "center";
  document.body.appendChild(p);
  document.getElementById("boton").onclick = function () {
    var b = document.getElementById("base").value;
    var h = document.getElementById("altura").value;
    alert("El triéngulo con base: " + b + " y altura: " + h + ", tiene como área: " + (b * h) / 2);

  };
}