window.onload = function () {
  document.getElementById("boton").onclick = function () {
    var b = document.getElementById("base").value;
    var h = document.getElementById("altura").value;
    var p = document.createElement("p");
    p.innerText = "Base: " + b + ", Altura: " + h + ", Área: " + (b * h);
    document.body.appendChild(p);
  };
}