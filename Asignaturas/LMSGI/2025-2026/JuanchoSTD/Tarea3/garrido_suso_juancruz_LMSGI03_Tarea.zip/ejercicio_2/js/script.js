window.onload = function () {
  document.getElementById("boton").onclick = function () {
    document.getElementById("parrafo").style.color = "green";
  };
}