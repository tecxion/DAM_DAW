window.onload = function () {
  var p = document.createElement("p");
  p.innerText = "Adiós";
  document.body.appendChild(p);
};