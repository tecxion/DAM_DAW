window.onload = function () {
  document.getElementById("boton").onclick = function () {
    alert("Hola " + document.getElementById("nombre").value);
  };
}