window.onload = function () {
  document.getElementById("parrafo").innerText = "Adiós";
};